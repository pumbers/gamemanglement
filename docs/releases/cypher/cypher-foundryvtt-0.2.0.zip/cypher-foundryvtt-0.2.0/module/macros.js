/**
 * Hotbar Macro Utilities
 * @module macros
 */

/**
 * Create a Macro from an Item drop.
 * Get an existing item macro if one exists, otherwise create a new one.
 * @param {Object} data     The dropped data
 * @param {number} slot     The hotbar slot to use
 * @returns {Promise}
 */
export async function createHotbarMacro(data, slot) {
  if (data.type == "Item") {
    if (!("data" in data))
      return ui.notifications.warn(game.i18n.localize("CYPHER.messages.createHotbarMacroItemNotOwned"));

    const item = data.data;

    // Create the macro command
    let command = `game.${game.data.system.id}.useItemMacro("${item._id}");`;
    let macro = game.macros.entities.find((m) => m.command === command);
    if (!macro) {
      macro = await Macro.create({
        name: item.name,
        type: "script",
        img: item.img,
        command: command,
        flags: { [`${game.data.system.id}.itemMacro`]: true },
      });
    }

    // Drop it in the hotbar
    game.user.assignHotbarMacro(macro, slot);
    return false;
  }
}

/**
 * Execute an item macro
 * @param {string} itemId
 * @return {Promise}
 */
export async function useItemMacro(itemId) {
  // try to determine the actor
  const speaker = ChatMessage.getSpeaker();
  let actor;
  if (speaker.token) actor = game.actors.tokens[speaker.token];
  if (!actor) actor = game.actors.get(speaker.actor);
  if (!actor) return ui.notifications.warn(game.i18n.localize("CYPHER.messages.useItemMacroCannotDetermineActor"));

  // Find the item in the actor's inventory
  const item = actor?.items.get(itemId);
  if (!item) return ui.notifications.warn(game.i18n.localize("CYPHER.messages.useItemMacroItemNotOwned"));

  // Trigger the item use
  return item.use();
}
