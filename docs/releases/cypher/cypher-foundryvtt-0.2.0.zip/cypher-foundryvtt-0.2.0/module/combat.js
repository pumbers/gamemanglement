/*
 *
 */
export function _getInitiativeRoll(combatant, formula) {
  const rollData = combatant.actor ? combatant.actor.getRollData() : {};

  switch (combatant.actor.data.type) {
    case "character":
      return new Roll(formula, rollData).roll();
    case "npc":
      return new Roll(`${combatant.actor.data.data.level * 3}`, rollData).roll();
  }
}
