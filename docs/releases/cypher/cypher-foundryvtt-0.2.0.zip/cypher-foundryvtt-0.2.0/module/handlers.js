/**
 * Sheet Event Handlers
 * @module handlers
 */

/**
 * Update a field on a character sheet form, usually based on a click event
 * @param {Event} event The originating change event
 * @author 3rdDog <paul.umbers@gmail.com>
 */
export function onSetField(event) {
  event.preventDefault();
  // Fetch the triggering element nd it's attached dataset
  const element = $(event.currentTarget);
  const dataset = element.data();
  const field = element?.closest("[data-field]").data("field");

  // Find the new value. If it's a String, data-dtype can be left unset, but Booleans and Numbers mus
  // be explicitly typed. Default type is String if dtype is not set or unrecognized.
  let value;
  if (dataset.dtype?.toLowerCase() === "number") {
    value = Number(element.data("value"));
  } else if (dataset.dtype?.toLowerCase() === "boolean") {
    value = Boolean(element.data("value"));
  } else {
    value = element.data("value");
  }

  this.actor?.update({ [field]: value });
}

/**
 * Handle creating a new Owned Item for the actor using initial data defined in the HTML dataset
 * @param {Event} event   The originating click event
 */
export function onItemCreate(event) {
  event?.preventDefault();
  const element = $(event?.currentTarget);
  const dataset = element?.data();
  // Initialize a default name.
  const name = `New ${dataset.type.capitalize()}`;
  // Prepare the item object.
  const itemData = {
    name: dataset.name || name,
    type: dataset.type,
    data: dataset,
  };
  // Remove the type from the dataset since it's in the itemData.type prop.
  delete itemData.data["type"];

  // Finally, create the item!
  return this.actor?.createOwnedItem(itemData);
}

/**
 * Handle editing an item by opening the item sheet
 * @param {Event} event   The originating click event
 */
export function onItemEdit(event) {
  event?.preventDefault();
  const element = $(event.currentTarget);
  const itemId = element?.closest("[data-item-id]").data("itemId");
  if (itemId) {
    const item = this.actor.getOwnedItem(itemId);
    item?.sheet.render(true);
  }
}

/**
 * Handle deleting an item
 * @param {Event} event   The originating click event
 */
export function onItemDelete(event) {
  event?.preventDefault();
  const element = $(event?.currentTarget);
  const itemId = element?.closest("[data-item-id]").data("itemId");
  if (itemId) {
    this.actor.deleteOwnedItem(itemId);
    element.slideUp(200, () => this.render(false));
  }
}

/**
 * Update an item field from a character sheet form; usually triggered by an onChange() event from the form.
 * @param {Event} event The originating change event
 * @author 3rdDog <paul.umbers@gmail.com>
 */
export function onUpdateItemField(event) {
  event.preventDefault();
  // Fetch the triggering element nd it's attached dataset
  const element = $(event.currentTarget);
  const dataset = element.data();
  const itemId = element?.closest("[data-item-id]").data("itemId");
  if (!itemId) return;

  // Find the new value. If it's a String, data-dtype can be left unset, but Booleans and Numbers mus
  // be explicitly typed. Default type is String if dtype is not set or unrecognized.
  let value;
  if (element.prop("type") === "checkbox") {
    value = element.prop("checked");
  } else if (dataset.dtype?.toLowerCase() === "number") {
    value = Number(element.val());
  } else if (dataset.dtype?.toLowerCase() === "boolean") {
    value = Boolean(element.val());
  } else {
    value = element.val();
  }

  // Find and update the item
  const item = this.actor.getOwnedItem(itemId);
  item?.update({ [dataset.field]: value }, {});
}

/**
 * Update or set/unset an item flag
 * @param {Event} event The originating change event
 */
export function onUpdateItemFlag(event) {
  event?.preventDefault();
  const element = $(event?.currentTarget);
  const dataset = element?.data();
  const itemId = element?.closest("[data-item-id]").data("itemId");
  if (!itemId) return;
  const item = this.actor?.getOwnedItem(itemId);

  let value;
  switch (dataset?.dtype?.toLowerCase()) {
    case "boolean":
      item?.setFlag(game.data.system.id, dataset.flag, Boolean(dataset.value));
      break;
    case "string":
      item?.setFlag(game.data.system.id, dataset.flag, dataset.value);
      break;
    case "number":
      item?.setFlag(game.data.system.id, dataset.flag, Number(dataset.value));
      break;
    default:
      item?.unsetFlag(game.data.system.id, dataset.flag);
      break;
  }
}

/**
 * Handle activation of item "use"
 * @param {Event} event   The originating click event
 */
export function onUseItem(event) {
  event.preventDefault();
  const element = $(event?.currentTarget);
  const { shiftKey, ctrlKey, altKey } = event;
  let itemId = element?.closest("[data-item-id]").data("itemId");
  if (itemId) {
    const item = this.actor.getOwnedItem(itemId);
    item?.use();
  }
}

/**
 * Handle activation of item "use"
 * @param {Event} event   The originating click event
 */
export function onChatItem(event) {
  event.preventDefault();
  const element = $(event?.currentTarget);
  const { shiftKey, ctrlKey, altKey } = event;
  let itemId = element?.closest("[data-item-id]").data("itemId");
  if (itemId) {
    const item = this.actor.getOwnedItem(itemId);
    item?.chat();
  }
}

/**
 * Handle clickable rolls.
 * @param {Event} event   The originating click event
 */
export function onRoll(event) {
  event.preventDefault();
  const element = $(event?.currentTarget);
  const dataset = element?.data();
  const { shiftKey, ctrlKey, altKey } = event;

  if (dataset?.roll) {
    let roll = new Roll(dataset.roll, this.actor.data.data);
    roll.roll().toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      flavor: dataset.label ? dataset.label : "Rolling",
      rollMode: shiftKey ? "gmroll" : game.settings.get("core", "rollMode"),
    });
  }
}

/**
 * Handle increment sheet value
 * @param {Event} event   The originating click event
 */
export function onIncrementValue(event) {
  event.preventDefault();
  const element = $(event?.currentTarget);
  const dataset = element?.data();
  const actor = this.actor;
  actor?.update({
    [dataset.value]: Math.min(getProperty(actor.data, dataset.value) + 1, parseInt(dataset.max) || 20),
  });
}

/**
 * Handle increment sheet value
 * @param {Event} event   The originating click event
 */
export function onDecrementValue(event) {
  event.preventDefault();
  const element = $(event?.currentTarget);
  const dataset = element?.data();
  const actor = this.actor;
  actor?.update({
    [dataset.value]: Math.max(getProperty(actor.data, dataset.value) - 1, parseInt(dataset.min) || 0),
  });
}
