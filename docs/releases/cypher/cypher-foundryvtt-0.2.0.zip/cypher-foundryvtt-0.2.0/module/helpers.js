/**
 * Handlebars Helpers
 * @module helpers
 */

/**
 * Concatenate a series of arguments into a single string
 * @param  {Array} arguments Array of arguments for concatenation, provided automatically by Handlebars
 */
export function concat() {
  var outStr = "";
  for (var arg in arguments) {
    if (typeof arguments[arg] != "object") {
      outStr += arguments[arg];
    }
  }
  return outStr;
}

/**
 * Upper case all characters
 * @param  {String} str Input string
 */
export function toLowerCase(str) {
  return str.toLowerCase();
}

/**
 * Lower case all characters
 * @param  {String} str Input String
 */
export function toUpperCase(str) {
  return str.toUpperCase();
}

/**
 * Use a template string with '{data}' items embedded to create an output string
 * @param  {String} stringId The id of the string in the language file to use as a template
 * @param  {Object} options options.hash contains all other named fields for use in the template
 */
export function format(stringId, options) {
  return game.i18n.format(stringId, options?.hash);
}

/**
 *
 */
export function offset(value, offset, options) {
  return Number(value) + Number(offset);
}

/**
 *
 */
export function object({ hash }) {
  return hash;
}

/**
 *
 */
export function array() {
  return Array.from(arguments).slice(0, arguments.length - 1);
}
