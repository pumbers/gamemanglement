/**
 * Extend the basic Item with some very simple modifications.
 * @extends {Item}
 */
export class CypherItem extends Item {
  /**
   * Augment the basic Item data model with additional dynamic data.
   */
  prepareData() {
    super.prepareData();
    // Get the Item's data
    const itemData = this.data;
    const actorData = this.actor ? this.actor.data : {};
    const data = itemData.data;
  }

  async use() {
    console.log("use", this._id, this.name);
    this.actor.update({ "data.task.current": this._id });
  }

  async chat() {
    console.dir("chat", this._id, this.name);
    const content = await renderTemplate("systems/cypher/templates/chat/item.hbs", this.data);
    ChatMessage.create({
      content: content,
      flavor: this.name,
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
    });
  }
}
