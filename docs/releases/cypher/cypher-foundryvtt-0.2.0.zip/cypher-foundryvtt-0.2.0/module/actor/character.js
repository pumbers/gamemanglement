/**
 * Extend the base Actor entity by defining a custom roll data structure which is ideal for the Simple system.
 * @extends {Actor}
 */
export class CypherCharacter extends Actor {
  /**
   * Augment the basic actor data with additional dynamic data.
   */
  prepareData() {
    super.prepareData();

    const actorData = this.data;
    const data = actorData.data;
    const flags = actorData.flags;

    // Make separate methods for each Actor type (character, npc, etc.) to keep
    // things organized.
    if (actorData.type === "character") this._prepareCharacterData(actorData);

    this._prepareItems(actorData);
  }

  /**
   * Prepare Character type specific data
   */
  _prepareCharacterData(actorData) {
    const data = actorData.data;

    // calculate damage status
    let damage = 0;
    if (data.stats.might.value === 0) ++damage;
    if (data.stats.speed.value === 0) ++damage;
    if (data.stats.intellect.value === 0) ++damage;
    data.damage.value = Math.max(data.damage.special, damage);

    // task roller setup
    // console.dir("task roller: starting state", data.task);
    // if we just switched tasks, reset to a default first
    if (!data.task || data.task.current !== data.task.last) {
      // console.log("... resetting task to default");
      data.task = {
        current: data.task?.current,
        last: data.task?.current,
        name: "Task Roll",
        isAttack: true,
        isDefense: true,
        damage: 0,
        settings: {
          difficulty: null,
          skill: 0,
          adjust: 0,
          effort: { free: 0, action: 0, damage: 0 },
          special: 0,
          stat: { key: null, cost: 0, canIncrease: true },
          powerShift: null,
        },
      };
      // Then, if a task item was selected set that up
      if (data.task.current) {
        // console.dir("finding item", data.task.current);
        let item = this.data.items.find((i) => i._id == data.task.current);
        // console.dir("configuring for", data.task.current, item?.name);
        data.task = mergeObject(data.task, {
          name: item?.name,
          isAttack: item?.data.use.isAttack,
          isDefense: item?.data.use.isDefense,
          damage: item?.data.use.damage,
          settings: {
            stat: {
              key: item?.data.use.stat.key,
              cost: item?.data.use.stat.cost,
              canIncrease: item?.data.use.stat.canIncrease,
            },
            skill: item?.data.use.skill,
            effort: { free: item?.data.use.effort.free },
            adjust: item?.data.use.adjust,
          },
        });
      }
    }

    // Task Result/Roll Calculation
    // console.dir("caclulating result for", data.task);
    data.task.result = {};
    // difficulty & target number
    data.task.result.difficulty = Math.max(
      0,
      data.task.settings.difficulty -
        ((data.task.settings.skill || 1) - 1) +
        (data.task.settings.adjust || 0) -
        (data.task.settings.effort?.action || 0) +
        data.task.settings.special
    );
    data.task.result.tn = data.task.result.difficulty * 3;
    // effort
    data.task.settings.effort.actionMin = 0;
    data.task.settings.effort.actionMax = data.effort;
    data.task.settings.effort.damageMin = 0;
    data.task.settings.effort.damageMax = data.effort;
    data.task.result.damage = (data.task.damage || 0) + (data.task.settings?.effort?.damage || 0) * 3;
    // Stat Cost
    data.task.result.stat = data.task.settings.stat.key;
    let statCost = data.task.settings.stat.cost || 0;
    let appliedEffort =
      (data.task.settings.effort.action || 0) +
      (data.task.settings.effort.damage || 0) -
      (data.task.settings.effort.free || 0);
    let edge = data.stats[data.task.settings?.stat?.key]?.edge;
    data.task.result.effort = appliedEffort;
    data.task.result.cost = statCost + Math.max(0, appliedEffort ? 1 + appliedEffort * 2 - edge : 0);
    // flags
    data.task.result.canRoll =
      !data.task.result.stat || data.stats[data.task.result.stat]?.value >= data.task.result.cost;

    // console.dir("task roller set", data.task);
  }

  /**
   * Organize and classify Owned Items for Character sheets
   * @private
   */
  _prepareItems(data) {
    const actorData = this.data;
    let update = data.items.reduce(
      (slots, item) => {
        // Organize items by type
        switch (item.type) {
          case "skill":
            slots.skills.push(item);
            break;
          case "ability":
            slots.abilities.push(item);
            break;
          case "powerShift":
            slots.powerShifts.push(item);
            break;
          case "arc":
            slots.arcs.push(item);
            break;
          case "item":
            slots.items.push(item);
            break;
          case "cypher":
            slots.cyphers.push(item);
            break;
          case "artifact":
            slots.artifacts.push(item);
            break;
        }
        if (item.data.use.isAttack || item.data.use.damage) slots.attacks.push(item);
        if (item.data.use.isDefense || item.data.use.armor) slots.defenses.push(item);
        return slots;
      },
      {
        skills: [],
        abilities: [],
        powerShifts: [],
        arcs: [],
        items: [],
        cyphers: [],
        artifacts: [],
        attacks: [],
        defenses: [],
      }
    );

    Object.assign(data.data, { ...update });
  }
}
