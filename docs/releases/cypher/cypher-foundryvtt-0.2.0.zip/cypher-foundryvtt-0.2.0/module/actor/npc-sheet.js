import * as Handlers from "../handlers.js";

/**
 * Extend the basic ActorSheet with some very simple modifications
 * @extends {ActorSheet}
 */
export class CypherNpcSheet extends ActorSheet {
  /** @override */
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["cypher", "sheet", "actor", "npc"],
      template: "systems/cypher/templates/actor/npc-sheet.hbs",
      width: 450,
      height: 650,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "main" }],
    });
  }

  /* -------------------------------------------- */

  /** @override */
  getData() {
    const data = super.getData();

    data.dtypes = ["String", "Number", "Boolean"];

    data.lists = {
      distances: game.i18n.translations.CYPHER.distance,
    };

    data.data.targetNumber = (data.data.level || 0) * 3;

    return data;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);

    // Everything below here is only needed if the sheet is editable
    if (!this.options.editable) return;

    // Drag events for moving inventory & creating macros
    if (this.actor.owner) {
      let handler = (event) => this._onDragItemStart(event);
      html.find(".item[draggable='true']").each((i, item) => {
        item.addEventListener("dragstart", handler, false);
      });
    }

    // Item actions
    html.find(".item-create").click(Handlers.onItemCreate.bind(this));
    html.find(".item-field-binding").change(Handlers.onUpdateItemField.bind(this));
    html.find(".item-flag-binding").click(Handlers.onUpdateItemFlag.bind(this));
    html.find(".item-use").click(Handlers.onUseItem.bind(this));
    html.find(".item-edit").click(Handlers.onItemEdit.bind(this));
    html.find(".item-delete").click(Handlers.onItemDelete.bind(this));

    // Rollable actions
    html.find(".rollable").click(Handlers.onRoll.bind(this));

    // Increment/decrement a sheet value
    html.find(".clickable.increment").click(Handlers.onIncrementValue.bind(this));
    html.find(".clickable.decrement").click(Handlers.onDecrementValue.bind(this));
  }
}
