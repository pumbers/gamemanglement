import * as Handlers from "../handlers.js";

/**
 * Extend the basic ActorSheet with some very simple modifications
 * @extends {ActorSheet}
 */
export class CypherCharacterSheet extends ActorSheet {
  /** @override */
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["cypher", "sheet", "actor", "character"],
      template: "systems/cypher/templates/actor/character-sheet.hbs",
      width: 800,
      height: 850,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }],
    });
  }

  /* -------------------------------------------- */

  /** @override */
  getData() {
    const data = super.getData();
    // const actorData = data.data;
    // console.dir("super.getData():data", data);

    // data types
    data.dtypes = ["String", "Number", "Boolean"];

    // lists for selects, etc
    data.lists = {
      advances: { ...game.i18n.translations.CYPHER.advances },
      recoveries: { ...game.i18n.translations.CYPHER.recoveries },
      damage: { ...game.i18n.translations.CYPHER.damage },
      difficulties: { ...game.i18n.translations.CYPHER.difficulty },
      skillLevels: { ...game.i18n.translations.CYPHER.skill.level },
    };

    // game settings
    data.settings = {
      useCharacterArcs: game.settings.get("cypher", "useCharacterArcs"),
      usePowerShifts: game.settings.get("cypher", "usePowerShifts"),
    };

    return data;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);

    // Everything below here is only needed if the sheet is editable
    if (!this.options.editable) return;

    // Drag events for moving inventory & creating macros
    if (this.actor.owner) {
      let handler = (event) => this._onDragItemStart(event);
      html.find(".item[draggable='true']").each((i, item) => {
        item.addEventListener("dragstart", handler, false);
      });
    }

    // Sheet Actions
    html.find(".set-field").click(Handlers.onSetField.bind(this));
    html.find(".clickable.increment").click(Handlers.onIncrementValue.bind(this));
    html.find(".clickable.decrement").click(Handlers.onDecrementValue.bind(this));
    html.find(".rollable").click(Handlers.onRoll.bind(this));

    html.find(".recovery-roll").click(this._onRecoveryRoll.bind(this));
    html.find(".task-roll").click(this._onTaskRoll.bind(this));
    html.find(".task-cost").click(this._onTaskCost.bind(this));

    // Item actions
    html.find(".item-create").click(Handlers.onItemCreate.bind(this));
    html.find(".item-field-binding").change(Handlers.onUpdateItemField.bind(this));
    html.find(".item-flag-binding").click(Handlers.onUpdateItemFlag.bind(this));
    html.find(".item-chat").click(Handlers.onChatItem.bind(this));
    html.find(".item-use").click(Handlers.onUseItem.bind(this));
    html.find(".item-edit").click(Handlers.onItemEdit.bind(this));
    html.find(".item-delete").click(Handlers.onItemDelete.bind(this));
  }

  _onRecoveryRoll(event) {
    event.preventDefault();
    const element = $(event?.currentTarget);
    const dataset = element?.data();
    const { shiftKey, ctrlKey, altKey } = event;
    let actorData = this.actor.data.data;
    new Roll(`1d6+${actorData.tier}`).roll().toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      flavor: dataset.label ? dataset.label : "Recovery Roll",
      rollMode: shiftKey ? "gmroll" : game.settings.get("core", "rollMode"),
    });
    this.actor?.update({ "data.recovery.used": Math.min(actorData.recovery.used + 1, 4) });
  }

  async _onTaskRoll(event) {
    const element = $(event?.currentTarget);
    const dataset = element?.data();
    const { shiftKey, ctrlKey, altKey } = event;
    const actorData = this.actor.data.data;
    const task = actorData.task;
    // console.log("_onTaskRoll()", task);
    if (task.settings.difficulty) {
      // difficulty has been set
      let roll = new Roll("1d20").roll();

      // calculate difficulty modifiers from settings
      let final = {
        skill: -(task.settings.skill || 0),
        adjust: task.settings.adjust || 0,
        effort: { action: -(task.settings.effort.action || 0) },
        special: -(task.settings.special || 0),
      };

      // calculate the final difficulty and if the roll beat it
      final.difficulty = Math.max(
        0,
        task.settings.difficulty + final.skill + final.adjust + final.effort.action + final.special
      );
      final.tn = final.difficulty * 3;
      final.beaten = roll.total >= final.tn;

      // calculate a final damage total
      final.damage = task.isAttack ? (task.damage || 0) + (task.settings.effort.damage || 0) * 3 : 0;

      // send the chat message
      roll.toMessage({
        speaker: ChatMessage.getSpeaker({ actor: this.actor }),
        flavor: dataset.label ? dataset.label : "Task",
        rollMode: shiftKey ? "gmroll" : game.settings.get("core", "rollMode"),
        content: await renderTemplate("systems/cypher/templates/chat/task-roll.hbs", { task, roll, final }),
      });
    } else {
      // no difficulty set, open roll
      let roll = new Roll("1d20").roll();

      // calculate dice modifiers from settings
      let final = {
        skill: (task.settings.skill || 0) * 3,
        adjust: -(task.settings.adjust || 0) * 3,
        effort: { action: (task.settings.effort.action || 0) * 3 },
        special: -(task.settings.special || 0) * 3,
      };

      // calculate the final dice total and the skills level it beats
      final.total = roll._total + final.skill + final.adjust + final.effort.action + final.special;
      final.beats = Math.floor(final.total / 3);

      // calculate a final damage total
      final.damage = task.isAttack ? (task.damage || 0) + (task.settings.effort.damage || 0) * 3 : 0;

      // send the chat message
      roll.toMessage({
        speaker: ChatMessage.getSpeaker({ actor: this.actor }),
        flavor: (dataset.label ? dataset.label : "Task") + " (Open)",
        rollMode: shiftKey ? "gmroll" : game.settings.get("core", "rollMode"),
        content: await renderTemplate("systems/cypher/templates/chat/quick-task-roll.hbs", { task, roll, final }),
      });
    }
  }

  async _onTaskCost(event) {
    const element = $(event?.currentTarget);
    const dataset = element?.data();
    const { shiftKey, ctrlKey, altKey } = event;
    const actorData = this.actor.data.data;
    const task = actorData.task;
    // console.log("_onTaskCost()", task);

    this.actor.update({
      [`data.stats.${task.result.stat}.value`]: Math.max(0, actorData.stats[task.result.stat].value - task.result.cost),
    });
  }
}
