// Import Modules
import { CypherCharacter } from "./actor/character.js";
import { CypherCharacterSheet } from "./actor/character-sheet.js";
import { CypherNpcSheet } from "./actor/npc-sheet.js";
import { CypherItem } from "./item/item.js";
import { CypherItemSheet } from "./item/item-sheet.js";
import { _getInitiativeRoll } from "./combat.js";

import * as Macros from "./macros.js";
import * as Helpers from "./helpers.js";

Hooks.once("init", async function () {
  game.cypher = {
    entities: { CypherCharacter, CypherItem },
    useItemMacro: Macros.useItemMacro,
  };

  /* -------------------------------------------- */
  /*  Game Settings                            
  /* -------------------------------------------- */

  /**
   * Set an initiative formula for the system
   * @type {String}
   */
  CONFIG.Combat.initiative = {
    formula: "1d20",
    decimals: 0,
  };

  // Register game system settings
  game.settings.register("cypher", "useCharacterArcs", {
    name: "Are you going to use Character Arcs?",
    hint: "Character arcs are an optional rule that can be used to add background and character development.",
    scope: "world",
    config: true,
    default: false,
    type: Boolean,
  });

  game.settings.register("cypher", "usePowerShifts", {
    name: "Are you going to use Power Shifts?",
    hint:
      "Power Shifts are an optional rule normally used in high-power genres, such as superheroes or gods. They provide free levels of effort when carrying out certain tasks.",
    scope: "world",
    config: true,
    default: false,
    type: Boolean,
  });

  // Set the combat initiative overrides
  Combat.prototype._getInitiativeRoll = _getInitiativeRoll;

  // Define custom Entity classes
  CONFIG.Actor.entityClass = CypherCharacter;
  CONFIG.Item.entityClass = CypherItem;

  /**
   * Set default values for new actor tokens
   */
  Hooks.on("preCreateActor", (createData) => {
    // Set wounds, advantage, and display name visibility
    mergeObject(createData, {
      "token.bar1": { attribute: "stats.might" }, // Default Bar 1 to Might
      "token.bar2": { attribute: "stats.speed" }, // Default Bar 2 to Speed
      "token.displayName": CONST.TOKEN_DISPLAY_MODES.ALWAYS, // Default display name to be always on
      "token.displayBars": CONST.TOKEN_DISPLAY_MODES.OWNER, // Default display bars to be on for owner
      "token.disposition": CONST.TOKEN_DISPOSITIONS.NEUTRAL, // Default disposition to neutral by default
      "token.name": createData.name, // Set token name to actor name
    });

    // Default characters to HasVision = true and Link Data = true
    if (createData.type == "character") {
      createData.token.vision = true;
      createData.token.actorLink = true;
    }
  });

  // Register sheet application classes
  Actors.unregisterSheet("core", ActorSheet);
  Actors.registerSheet("cypher", CypherCharacterSheet, { types: ["character"], makeDefault: true });
  Actors.registerSheet("cypher", CypherNpcSheet, { types: ["npc"], makeDefault: true });
  Items.unregisterSheet("core", ItemSheet);
  Items.registerSheet("cypher", CypherItemSheet, { makeDefault: true });

  /* -------------------------------------------- */
  /*  Handlebars Helpers & Partials                      
  /* -------------------------------------------- */

  Handlebars.registerHelper("concat", Helpers.concat);
  Handlebars.registerHelper("toLowerCase", Helpers.toLowerCase);
  Handlebars.registerHelper("toUpperCase", Helpers.toUpperCase);
  Handlebars.registerHelper("format", Helpers.format);
  Handlebars.registerHelper("offset", Helpers.offset);
  Handlebars.registerHelper("object", Helpers.object);
  Handlebars.registerHelper("array", Helpers.array);

  loadTemplates([
    "systems/cypher/templates/actor/_arcs-list.hbs",
    "systems/cypher/templates/actor/_skills-list.hbs",
    "systems/cypher/templates/actor/_abilities-list.hbs",
    "systems/cypher/templates/actor/_powershifts-list.hbs",
    "systems/cypher/templates/actor/_items-list.hbs",
    "systems/cypher/templates/actor/_cyphers-list.hbs",
    "systems/cypher/templates/actor/_artifacts-list.hbs",
    "systems/cypher/templates/actor/_task-roller.hbs",
    "systems/cypher/templates/chat/_task-roll.hbs",
    "systems/cypher/templates/chat/_quick-task-roll.hbs",
  ]);
});

/* -------------------------------------------- */
/*  Hotbar Macros                               
/* -------------------------------------------- */

Hooks.once("ready", async function () {
  // Wait to register hotbar drop hook on ready so that modules could register earlier if they want to
  Hooks.on("hotbarDrop", (bar, data, slot) => Macros.createHotbarMacro(data, slot));
});
